# Fiş Takip

Market ve yakıt fişlerini fotoğraftan okuyan, takvimli kişisel bütçe takip uygulaması.

## Klasörler
- `artifact/index.html` — claude.ai üzerinde çalışan güncel sürüm (tek dosya: HTML/CSS/JS)
- `artifact/v1.html` — ilk sürümün yedeği
- `server/` — Claude'a bağımlı olmadan kendi sunucunda çalışan sürüm (Express + Anthropic API)

## Özellikler
Fiş fotoğrafı okuma, takvim, fişsiz harcama ve tekrarlı giderler, aylık ve genel istatistikler,
fiyat değişimi (enflasyon) takibi, tasarruf önerileri, gelir/yatırım/birikim ve harcanabilir kalan.

## Sunucu sürümünü çalıştırma
```
cd server
npm install
ANTHROPIC_API_KEY=... ACCESS_CODE=... npm start
```
Ayrıntılar `server/README.md` içinde. API anahtarını asla depoya koyma.
